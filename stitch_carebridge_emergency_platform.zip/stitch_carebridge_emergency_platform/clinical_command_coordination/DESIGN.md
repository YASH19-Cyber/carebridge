---
name: Clinical Command & Coordination
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#47464f'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#787680'
  outline-variant: '#c8c5d0'
  surface-tint: '#5b598c'
  primary: '#070235'
  on-primary: '#ffffff'
  primary-container: '#1e1b4b'
  on-primary-container: '#8683ba'
  inverse-primary: '#c4c1fb'
  secondary: '#0051d5'
  on-secondary: '#ffffff'
  secondary-container: '#316bf3'
  on-secondary-container: '#fefcff'
  tertiary: '#000e0c'
  on-tertiary: '#ffffff'
  tertiary-container: '#002723'
  on-tertiary-container: '#1a998d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c4c1fb'
  on-primary-fixed: '#181445'
  on-primary-fixed-variant: '#444173'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b4c5ff'
  on-secondary-fixed: '#00174b'
  on-secondary-fixed-variant: '#003ea8'
  tertiary-fixed: '#89f5e7'
  tertiary-fixed-dim: '#6bd8cb'
  on-tertiary-fixed: '#00201d'
  on-tertiary-fixed-variant: '#005049'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  metric-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.03em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The platform delivers an authoritative, high-clarity operational environment tailored for hospital networks, clinical leads, triage specialists, and emergency operations coordinators. In high-stakes medical coordination, cognitive overload costs lives; the design language therefore balances absolute institutional reliability with rapid scanning ergonomics.

Drawing from modern **Corporate / Modern** precision coupled with **Tonal Layering** and focused clinical instrumentation:
- **Atmosphere:** Controlled, calm, immaculately organized, and high-trust.
- **Visual Stance:** Crisp boundaries, high typographic legibility, micro-status telemetry, and tactical contrast accents that isolate critical patient signals from routine administrative data.
- **Emotional Response:** Reassurance, operational confidence, immediate orientation during crisis states, and frictionless cognitive flow across 12-hour shifts.

## Colors
The color architecture establishes immediate visual hierarchy: deep structural anchors govern navigation, clinical blues signal interactive affordances, soothing teal accents monitor stable baseline processes, and dedicated alert hues isolate acute anomalies.

### Core Palette Application
- **Primary (`#1E1B4B` - Midnight Indigo):** Anchors global chrome, high-priority operational headers, active navigation rails, and primary data boundaries.
- **Secondary (`#2563EB` - Clinical Cobalt):** Dedicated to core interactive states, actionable buttons, active filter chips, focused form perimeters, and key patient pathway links.
- **Tertiary (`#0D9488` - Diagnostic Teal):** Signifies telemetry stability, verified practitioner verifications, coordinated handoffs, and ambient baseline operational metrics.
- **Neutral Dark (`#0F172A` - Obsidian Slate):** Solely reserved for primary patient identifiers, bed numbers, and critical headline text, ensuring contrast ratios exceeding 12:1.

### Functional & Alert Hierarchy
- **Clinical Success (`#10B981` / Background `#ECFDF5`):** Bed available, vitals stabilized, routine order fulfilled.
- **Warning / Triage Priority 2 (`#F59E0B` / Background `#FFFBEB`):** Delayed transfer, lab pending > 45 mins, bed allocation nearing threshold.
- **Critical / Emergency Code Red (`#DC2626` / Pulse Accent `#EF4444` / Background `#FEF2F2`):** Trauma incoming, ICU saturation alert, code blue triggers, emergency override hot-actions.

### Canvas & Surface Architecture
- **App Canvas:** `#F8FAFC` (Clinical Slate 50) minimizes eye strain under fluorescent hospital lighting.
- **Base Surfaces:** `#FFFFFF` (Pristine White) provides pure contrast for metric containers, patient cards, and tabular records.
- **Borders & Separators:** `#E2E8F0` (Structural Slate 200) ensures crisp delineation without dense visual barriers.
- **Muted Labeling:** `#475569` (Clinical Slate 600) for timestamps, secondary metric labels, and unit denominators.

## Typography
Typographic discipline pairs the structural geometric clarity of **Plus Jakarta Sans** for dashboards, headlines, and KPI telemetry with the reading ergonomics of **Inter** for dense clinical documentation and high-density tabular grids.

### Numerical & Data Conventions
- Metric values, physiological stats (SpO2, heart rate, blood pressure), timestamps, and dosages must enforce tabular numeral positioning (`font-variant-numeric: tabular-nums;`) to prevent layout shifts during live polling cycles.
- Small labels and data grid column headers (`label-sm`) require an uppercase treatment paired with `+0.04em` tracking to preserve legibility at low-contrast thresholds.
- Avoid font weights below `400`. Critical diagnostic markers utilize `600` or `700` weight to instantly lead the eye.

## Layout & Spacing
The layout model employs a responsive 12-column fluid grid system with strict 8pt rhythm multiples, engineered for high-density command dashboards and responsive bedside tablets.

### Grid & Breakpoint Logic
- **Desktop Command Console (≥ 1280px):** 12-column structure with `24px` (`1.5rem`) gutters and `32px` (`2rem`) outer margins. Supports persistent left-hand navigation rails (fixed `260px` or compact `72px`), dual-pane patient records, and real-time situational feeds.
- **Tablet / Clinical Cart (768px – 1279px):** 8-column layout with `16px` gutters. Navigational rails collapse to an icon-only docking strip. Actionable drawers slide over secondary details.
- **Mobile Handheld (< 768px):** 4-column layout with `12px` gutters and `16px` margins. Critical triage counters and alerts pin to top and bottom toolbars; complex tabular views reflow into stacked priority status cards.

### Spacing Principles
- Component internal padding strictly follows `space-xs` (4px) for compact badges, `space-sm` (8px) for input and button gaps, `space-md` (16px) for card body interiors, and `space-lg` (24px) for modular grid panel separations.
- Density adjustments: Operational command dashboards default to high-density spacing (reduced component gaps) to guarantee zero unnecessary vertical scrolling for critical vitals and ambulance arrival status.

## Elevation & Depth
Depth in this design system emphasizes clinical clarity over decorative skeuomorphism. It relies on crisp **Tonal Layering** combined with calibrated, cool-tinted **Ambient Shadows** to preserve perceptual order across stacked clinical interfaces.

### Elevation Hierarchy
- **Canvas (Level 0):** `#F8FAFC` — Base background plane. No shadow.
- **Base Cards & Workspaces (Level 1):** `#FFFFFF` bordered with `1px solid #E2E8F0`. Shadow: `0 1px 3px 0 rgba(15, 23, 42, 0.05), 0 1px 2px -1px rgba(15, 23, 42, 0.05)`. Used for KPI summaries, patient charts, and table rows.
- **Interactive Hover & Action Panels (Level 2):** `#FFFFFF` bordered with `1px solid #CBD5E1`. Shadow: `0 4px 6px -1px rgba(15, 23, 42, 0.07), 0 2px 4px -2px rgba(15, 23, 42, 0.05)`. Indicates interactive priority cards and hovered row containers.
- **Overlays, Popovers, & Dropdown Menus (Level 3):** `#FFFFFF` bordered with `1px solid #E2E8F0`. Shadow: `0 10px 15px -3px rgba(15, 23, 42, 0.10), 0 4px 6px -4px rgba(15, 23, 42, 0.05)`.
- **Emergency Action Dialogs & Critical Alerts (Level 4):** Shadow: `0 20px 25px -5px rgba(15, 23, 42, 0.15), 0 8px 10px -6px rgba(15, 23, 42, 0.08)`. Paired with a backdrop blur overlay (`rgba(15, 23, 42, 0.60)` with `backdrop-filter: blur(4px)`) to completely disconnect background activity during emergency protocol overrides.

Shadows are tinted with slate-obsidian (`rgba(15, 23, 42, ...)`) rather than pure black, maintaining a clean medical aesthetic without muddy edges.

## Shapes
A unified roundedness scale of `2` (`0.5rem` / `8px` default corner radius) creates a balanced, modern, and friendly profile while respecting rigid enterprise layouts.

### Structural Radius Allocations
- **Base Components (`8px`):** Standard buttons, text fields, notification toasts, dropdown menus, and standard card containers.
- **Compact Signals & Controls (`4px` / `rounded-sm`):** Status indicators, data table checkboxes, timeline node notches, and tabular cell tags.
- **Large Layout Containers (`12px` - `16px` / `rounded-lg` - `rounded-xl`): Modal containers, diagnostic flyout panels, and primary command metrics blocks.
- **Status Pills & Telemetry Badges (`9999px` / `rounded-full`):** Triage tags (e.g., "Code Yellow", "Triage P1"), presence indicators, patient condition badges, and numerical counter avatars.

## Components

### 1. Navigation & Emergency Hot-Action Bar
- **Header Structure:** Height of `68px`, structured with a deep Midnight Indigo background (`#1E1B4B`) or pure white surface with a `#E2E8F0` dividing border. Left: Department switcher & live clinic breadcrumbs. Center: Global patient universal search (with shortcut `⌘K`). Right: Live department status telemetry and hot-action controls.
- **Emergency Hot-Action Trigger:** Standout high-priority button (`#DC2626` background, `#FFFFFF` text, `0.5rem` radius). Includes a persistent pulsing red ring (`box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.35)`) and bold icon trigger. Instantly summons Code Blue, Trauma Triage, or Mass Casualty protocols from any screen.

### 2. Live Status Indicators
- **Pulse Beacons:** 8px circular badges paired with an animated outer halo displaying ping updates (every 5-15s).
- **Semantics:**
  - *Normal/Connected:* `#10B981` with emerald ping animation.
  - *Caution/Approaching Capacity:* `#F59E0B` with steady amber glow.
  - *Emergency Critical/Bypass Active:* `#DC2626` with rapid 1s interval pulse.

### 3. Metric KPI Cards with Delta Trends
- **Surface:** Level 1 elevation, `#FFFFFF` fill, `8px` radius, `16px` inner padding.
- **Layout:** Top row holds category label in `label-sm` (`#475569`) with an icon indicator. Center displays the value using `metric-display` in tabular figures (`#0F172A`).
- **Trend Footers:** Integrates a delta trend indicator pill with an arrow icon. Positive trends in throughput use `#ECFDF5` background with `#047857` text; adverse delays or bed shortages use `#FEF2F2` background with `#B91C1C` text. Includes an inline micro-sparkline showing the rolling 4-hour trend.

### 4. Actionable Tables with Status Badges
- **Header:** Sticky header row with `#F8FAFC` background, `1px solid #E2E8F0`, typography styled with `label-sm` uppercase.
- **Row Interaction:** Hover state activates `#F1F5F9` smoothly. Double-clicking or pressing Enter triggers patient quick-view.
- **Status Badges:** Fully rounded pills (`rounded-full`, 24px height, horizontal padding `10px`).
  - *Admitted / Stable:* `#ECFDF5` text `#065F46` (with `6px` solid dot).
  - *Triage Review:* `#EFF6FF` text `#1E40AF`.
  - *Delayed / Critical Attention:* `#FEF2F2` text `#991B1B`.
- **Quick Row Actions:** Row hover reveals an aligned action button cluster (e.g., Transfer Bed, Assign Doctor, Escalate).

### 5. Emergency Timeline Tracker
- **Visual Path:** Vertical or horizontal progression line in `2px solid #E2E8F0`. Passed phases fill with `#2563EB` (Routine) or `#DC2626` (Emergency).
- **Event Nodes:** 24px circular hubs with status iconography. Active node features a double-ring glow.
- **Node Content:** Timestamp aligned precisely in tabular figures (`14:32:05`), actionable title (`Triage Complete -> Cath Lab En Route`), performer credentials (`Dr. Sarah Lin, MD`), and elapsed phase duration tags.

### 6. Command Action Modal Triggers & Drawers
- **Overlays:** Centered critical dialogs or full-height right-hand sliding drawers (`width: 480px` or `640px`).
- **Header:** Explicit classification banner (e.g., deep red header for "Confirm Code Override", slate header for "Assign Inpatient Bed").
- **Action Footers:** Two-button hierarchy with clear microcopy. Secondary action uses transparent outline; confirmation action uses destructive `#DC2626` or primary `#2563EB`. Modals mandate keyboard escape listeners and explicit focus trapping.

### 7. Form Inputs & Interactive Controls
- **Input Fields:** Height `40px`, background `#FFFFFF`, border `1px solid #CBD5E1`, text `body-md` (`#0F172A`). Focus state: Border transitions to `#2563EB` with a `3px` focus ring in `rgba(37, 99, 235, 0.15)`.
- **Checkboxes & Radios:** `18px` square or circle, `#2563EB` on active check, high-contrast check mark (`#FFFFFF`).
- **Interactive Chips:** Multi-select filtering for specialties (e.g., "Cardiology", "Trauma", "Pediatrics"). Active chips use deep indigo `#1E1B4B` with white text; idle chips use `#F1F5F9` background with `#475569` text.